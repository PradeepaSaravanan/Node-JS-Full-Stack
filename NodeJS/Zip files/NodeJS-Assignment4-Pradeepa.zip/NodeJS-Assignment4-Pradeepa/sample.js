let arr= [1,2,3,4];
let x= arr.map( function(x){
    return x*2;
}
   
);
console.log(x);
console.log(arr);