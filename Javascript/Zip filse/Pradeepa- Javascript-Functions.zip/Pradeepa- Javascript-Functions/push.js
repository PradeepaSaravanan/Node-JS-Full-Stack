function arrPush(arr,value){
  arr[arr.length]=value;
  return arr.length;
}
var arr=[23,19,24,20,28];
pushValue=3;

console.log(arrPush(arr,pushValue));

//console.log(arr);


