function arrPop(arr){
    let x=arr[arr.length-1];
    let len= arr.length=arr.length-1;
    return x;

}

var arr=[12,13,14,14,15];
console.log(arrPop(arr));
