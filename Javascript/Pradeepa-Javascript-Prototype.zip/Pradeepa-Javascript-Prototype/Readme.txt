
step 1: create a base class Curriculum and set the peoperty.
step 2: Create a method named enrollStudent() to enroll students in the curriculum
step 3: Create a child class named Cbse.
step 4: Inherit the properties of Curriculum to Cbse by assigning instance of curriculum to Cbse.prototype
step 5: call enrollStudent method using instance of Cbse.
step 6: type Cbse.prototype in console , it returns the prototype which are created.
step 3: Create one more child class named Icse.
step 4: Inherit the properties of Curriculum to icse by assigning instance of curriculum to Icse.prototype
step 5: call displayDetails method using instance of Icse.
step 6: type Icse.prototype in console , it returns the prototype which are created.


